//
//  Snap.swift
//  Snapchat
//
//  Created by Jordan Revata Cuela on 7/11/18.
//  Copyright © 2018 Tecsup. All rights reserved.
//

import Foundation
class Snap{
    var imagenURL = ""
    var audioURL = ""
    var descrip = ""
    var from = ""
    var id = ""
    var imagenID = ""
    var audioID = ""
}
