//
//  Usuario.swift
//  Snapchat
//
//  Created by Jordan Revata Cuela on 2/11/18.
//  Copyright © 2018 Tecsup. All rights reserved.
//

import Foundation

class Usuario{
    
    var email = ""
    var uid   = ""
}
