//
//  IniciarSesionViewController.swift
//  Lab10Snapchat
//
//  Created by Fernanda  on 24/10/18.
//  Copyright © 2018 Fernanda Alvarado. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth

class IniciarSesionViewController: UIViewController {

    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func IniciarSesionTapped(_ sender: Any) {
        FIRAuth.auth()?.signIn(withEmail: emailTextField.text!, password: passwordTextField.text!, completion: {(user, err) in
            print("Intentemos iniciar sesion")
            if err != nil {
                print("Tenemos el siguiente error: \(String(describing: err))")
                FIRAuth.auth()?.createUser(withEmail: self.emailTextField.text!, password: self.passwordTextField.text!, completion: {(user, err) in print("Intentamos crear un usuario")
                    if err != nil{
                        print("Tenemos el siguiente error\(String(describing: err))")
                    }else{
                        print("El usuario fue creado exitosamente")
                        FIRDatabase.database().reference().child(user!.uid).child("email").setValue(user!.email); self.performSegue(withIdentifier: "iniciarsesionsegue", sender: nil)
                    }
                })
            } else {
                print("Inicio de sesion")
                self.performSegue(withIdentifier: "iniciarsesionsegue", sender: nil)
            }
        })
    }

}

